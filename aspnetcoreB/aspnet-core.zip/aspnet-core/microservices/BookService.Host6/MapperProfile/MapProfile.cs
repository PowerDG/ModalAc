﻿using AutoMapper;
using BookService.Host.Models;
using BookService.Host.Models.Dtos;
using BookService.Host.Web;

namespace BookService.Host.MapperProfile
{
    public class MapProfile : Profile
    {
        public MapProfile()
        {
            CreateMap<FundModel, FundListDto>().ConstructUsing(x => new FundListDto()
            { MemberName = UserNameHelper.GetUserName(x.MemberId) }); ;
            CreateMap<FundCreateDto, FundModel>();

            CreateMap<FundEditDto, FundModel>();
            CreateMap<FundModel, FundEditDto>();

            CreateMap<PartyCreateDto, Party>();
            CreateMap<PartyCreateDto, PartyEditDto>();
            CreateMap<PartyEditDto, Party>();
            CreateMap<Party, PartyListDto>();

            CreateMap<PartyCommentDto, PartyComment>();
            CreateMap<PartyComment, PartyCommentDto>();

            CreateMap<PartyPhotoDto, PartyPhoto>();
            CreateMap<PartyPhoto, PartyPhotoDto>();
        }
    }
}