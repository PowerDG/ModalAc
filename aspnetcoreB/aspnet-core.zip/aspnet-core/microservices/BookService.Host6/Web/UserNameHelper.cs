﻿using System.Collections.Generic;

namespace BookService.Host.Web
{
    public class UserNameHelper
    {
        public static Dictionary<int, string> UserSelectDtos { get; set; } = new Dictionary<int, string>();

        public static string GetUserName(int id)
        {
            UserSelectDtos.TryGetValue(id, out string name);
            return name;
        }
    }
}