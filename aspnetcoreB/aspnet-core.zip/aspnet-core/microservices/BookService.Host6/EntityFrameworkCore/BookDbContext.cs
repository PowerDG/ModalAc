﻿using Abp.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BookService.Host.EntityFrameworkCore
{
    public class BookDbContext : AbpDbContext
    {
        //Add DbSet properties for your entities...

        //public DbSet<FundModel> Fund { get; set; }
        //public DbSet<Party> Parties { get; set; }
        //public DbSet<PartyPhoto> PartyPhotos { get; set; }
        //public DbSet<PartyComment> PartyComments { get; set; }

        public BookDbContext(DbContextOptions<BookDbContext> options)
            : base(options)
        {
        }
    }
}