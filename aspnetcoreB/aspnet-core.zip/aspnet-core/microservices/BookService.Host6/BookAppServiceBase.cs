﻿using Abp.Application.Services;
using BookService.Host;

namespace BookService.Host
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class BookAppServiceBase : ApplicationService
    {
        protected BookAppServiceBase()
        {
            LocalizationSourceName = BookServiceHostConsts.LocalizationSourceName;
        }
    }
}