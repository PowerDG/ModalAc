﻿using Microsoft.AspNetCore.Mvc;

namespace ImageService.Host.Controllers
{
    [Route("api/[controller]/[Action]")]
    //    [ApiController]
    //    [Produces("application/json")]
    public class BaseController : ControllerBase
    {
    }
}