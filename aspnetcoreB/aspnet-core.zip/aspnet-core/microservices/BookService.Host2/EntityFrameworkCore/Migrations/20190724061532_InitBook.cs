﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace BookService.Host.EntityFrameworkCore.Migrations
{
    public partial class InitBook : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BookReviews",
                columns: table => new
                {
                    id = table.Column<uint>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    book_id = table.Column<uint>(nullable: false),
                    review = table.Column<string>(nullable: true),
                    score = table.Column<uint>(nullable: false),
                    is_active = table.Column<bool>(nullable: false),
                    creator_user_id = table.Column<long>(nullable: true),
                    create_time = table.Column<DateTime>(nullable: false),
                    last_modifier_user_id = table.Column<long>(nullable: true),
                    modified_time = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookReviews", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Books",
                columns: table => new
                {
                    id = table.Column<uint>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    name = table.Column<string>(maxLength: 30, nullable: false),
                    member_id = table.Column<long>(nullable: true),
                    author = table.Column<string>(nullable: true),
                    photo = table.Column<string>(nullable: true),
                    photo_hd = table.Column<string>(nullable: true),
                    entry_time = table.Column<DateTime>(nullable: false),
                    average_score = table.Column<decimal>(nullable: false),
                    number_of_book_review = table.Column<uint>(nullable: false),
                    resource = table.Column<string>(nullable: true),
                    state = table.Column<byte>(nullable: false),
                    last_book_review = table.Column<string>(nullable: true),
                    is_active = table.Column<bool>(nullable: false),
                    creator_user_id = table.Column<long>(nullable: true),
                    create_time = table.Column<DateTime>(nullable: false),
                    last_modifier_user_id = table.Column<long>(nullable: true),
                    modified_time = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Books", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BookReviews");

            migrationBuilder.DropTable(
                name: "Books");
        }
    }
}
