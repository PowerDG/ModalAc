﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace BookService.Host.EntityFrameworkCore.Migrations
{
    public partial class BillInitaffich : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BillInfoes",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false),
                    BillNo = table.Column<int>(nullable: false),
                    IsCandidate = table.Column<bool>(nullable: false),
                    Version = table.Column<int>(nullable: false),
                    SendBranchID = table.Column<string>(nullable: true),
                    BillCheck = table.Column<bool>(nullable: false),
                    BillStateID = table.Column<int>(nullable: false),
                    TOTAL_CHARGES = table.Column<string>(nullable: true),
                    BillImgUrl = table.Column<string>(nullable: true),
                    CreatorUserId = table.Column<long>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    DeleterUserId = table.Column<long>(nullable: true),
                    DeletionTime = table.Column<DateTime>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    LastModifierUserId = table.Column<long>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BillInfoes", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BillInfoes");
        }
    }
}
