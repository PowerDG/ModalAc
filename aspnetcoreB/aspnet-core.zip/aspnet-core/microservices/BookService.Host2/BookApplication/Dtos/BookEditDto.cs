using System;
using System.ComponentModel.DataAnnotations;
using Abp.AutoMapper;
using Abp.Domain.Entities.Auditing;
using BookService.Host.Domain;

namespace BookService.Host.Domain.Dtos
{
    [AutoMap(typeof(Book))]
    public class BookNameEditDto
    {
        public uint? Id { get; set; }

        /// <summary>
        /// 书名
        /// </summary>
        public string Name { get; set; }
    }

    [AutoMap(typeof(Book))]
    public class BookEditDto
    {
        /// <summary>
        /// Id
        /// </summary>
        public uint? Id { get; set; }

        /// <summary>
        /// 书名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 作者
        /// </summary>
        public string Author { get; set; }

        /// <summary>
        /// 缩略图
        /// </summary>
        public string Photo { get; set; }

        /// <summary>
        /// 高清图
        /// </summary>
        public string PhotoHd { get; set; }

        /// <summary>
        /// 书籍来源
        /// </summary>
        public string Resource { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public byte State { get; set; }

        /// <summary>
        /// 激活状态
        /// </summary>
        public bool IsActive { get; set; }
    }
}