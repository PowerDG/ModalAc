using Abp.Application.Services.Dto;

namespace BookService.Host.Dtos
{
    public class PagedAndSortedInputDto : PagedInputDto, ISortedResultRequest
    {
        public string Sorting { get; set; }

        public PagedAndSortedInputDto()
        {
            MaxResultCount = BookServiceHostConsts.DefaultPageSize;
        }
    }
}