﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookService.Host.Domain
{
    public class BookSourceDictionary
    {
        public new uint Id { get; set; } 
        public string Resource { get; set; }
    }
}
