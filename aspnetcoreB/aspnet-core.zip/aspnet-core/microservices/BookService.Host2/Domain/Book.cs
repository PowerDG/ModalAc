﻿using Abp.Domain.Entities;
using Abp.Domain.Entities.Auditing;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookService.Host.Domain
{
    public class Book : Entity<uint>, IAudited, IPassivable
    {
        public Book()
        {
            CreationTime = DateTime.Now;
            AverageScore = 0.00M;
            EntryTime = DateTime.Now;
            LastModificationTime = DateTime.Now;
        }

        [Column("id")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public new uint? Id { get; set; }

        [DisplayName("书籍名称"), Required, StringLength(30, MinimumLength = 16)]
        [Column("name")]
        public string Name { get; set; }

        [Column("member_id")]
        public long? MemberId { get; set; }

        [Column("author")]
        public string Author { get; set; }

        [Column("photo")]
        public string Photo { get; set; }

        [Column("photo_hd")]
        public string PhotoHd { get; set; }

        [Column("entry_time")]
        public DateTime EntryTime
        {
            get; set;
            //get
            //{
            //    return EntryTime;
            //}
            //set
            //{
            //    EntryTime = value != null ? value : DateTime.Now;
            //}
        }

        [Column("average_score")]
        public decimal AverageScore { get; set; }

        [Column("number_of_book_review")]
        public uint NumberOfBookReview { get; set; }

        [DisplayName("书籍来源")]
        [Column("resource")]
        public string Resource { get; set; }

        [Column("state")]
        public byte State { get; set; }

        [Column("last_book_review")]
        public string LastBookReview { get; set; }

        public void BorrowBooks()
        {
            State = 1;
        }

        public void ReturnBooks()
        {
            State = 0;
        }

        public void RemoveOfReportLoss()
        {
            State = 0;
        }

        public void ReportLoss()
        {
            State = 2;
        }

        #region Auditing

        [Column("is_active")]
        public bool IsActive { get; set; }

        [Column("creator_user_id")]
        public long? CreatorUserId { get; set; }

        [Column("create_time")]
        public DateTime CreationTime { get; set; }

        [Column("last_modifier_user_id")]
        public long? LastModifierUserId { get; set; }

        [Column("modified_time")]
        public DateTime? LastModificationTime { get; set; }

        #endregion Auditing
    }
}