﻿using Abp.Domain.Services;

namespace BookService.Host
{
    public abstract class BookDomainServiceBase : DomainService
    {
        protected BookDomainServiceBase()
        {
            LocalizationSourceName = BookServiceHostConsts.LocalizationSourceName;
        }
    }
}