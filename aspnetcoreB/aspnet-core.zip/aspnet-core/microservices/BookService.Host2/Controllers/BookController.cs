﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Abp.Application.Services.Dto;
using Abp.AspNetCore.Mvc.Controllers;
using Abp.AutoMapper;
using Abp.Domain.Repositories;
using Abp.Linq.Extensions;

using Microsoft.EntityFrameworkCore;

using System.Collections.Immutable;
using System.Linq.Dynamic.Core;
using BookService.Host.Domain.DomainService;
using BookService.Host.Domain;
using BookService.Host.Domain.Dtos;
using AutoMapper;
using Abp.Domain.Uow;
using Abp.UI;
using ResearchService.Host.Web;
using Newtonsoft.Json;

namespace BookService.Host.Controllers
{
    //[Route("api/[Controller]")]
    [Route("api/[Controller]/[Action]")]
    //[ApiController]
    public class BookController : AbpController
    {
        private readonly IUnitOfWorkManager m_unitOfWorkManager;
        protected IHttpContextAccessor m_accessor;
        private readonly IRepository<Book, uint> m_entityRepository;
        private readonly BookManager m_entityManager;

        /// <summary>
        /// 构造函数
        ///</summary>
        public BookController(
            IUnitOfWorkManager unitOfWorkManager
            , IRepository<Book, uint> entityRepository
            , IHttpContextAccessor accessor
            , BookManager entityManager
        )
        {
            m_unitOfWorkManager = unitOfWorkManager;
            m_accessor = accessor;
            m_entityRepository = entityRepository;
            m_entityManager = entityManager;
        }

        [HttpGet]
        /// <summary>
        /// 获取Book的分页列表信息
        ///</summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //[AbpAuthorize(BookPermissions.Query)]
        public async Task<PagedResultDto<BookListDto>> GetPaged(GetBooksInput input)
        {
            var query = m_entityRepository.GetAll();
            // TODO:根据传入的参数添加过滤条件
            var count = await query.CountAsync()
              //.WhereIf(string.IsNullOrWhiteSpace(input.FilterText), t => t.CreationTime == input.SkipCount)
              ;
            if (!string.IsNullOrEmpty(input.FilterText))
            {
                //query = query.Where(input.FilterText);
                var searchByAuthor = query.Where(s => s.Author.Contains(input.FilterText));
                var searchByName = query.Where(s => s.Name.Contains(input.FilterText));
                query = searchByAuthor.Union(searchByName);
            }
            var entityList = await query
                    .OrderBy(input.Sorting).AsNoTracking()
                    .PageBy(input)
                    .Distinct()
                    .ToListAsync();
            var entityListDtos = Mapper.Map<List<BookListDto>>(entityList);
            return new PagedResultDto<BookListDto>(count, entityListDtos);
        }

        /// <summary>
        /// 通过指定id获取BookListDto信息
        /// </summary>
        //[AbpAuthorize(BookPermissions.Query)]

        [HttpGet]
        public async Task<BookListDto> GetById(EntityDto<uint> input)
        {
            var entity = await m_entityRepository
            .FirstOrDefaultAsync(x => x.Id == input.Id);
            return Mapper.Map<BookListDto>(entity);
        }

        [HttpGet]
        public long GetCurrentUserId()
        {
            string auth = m_accessor.HttpContext.Request.Headers["Authorization"];
            var token = JwtDecodeHelper.JWTDecoder(auth);
            var userToekn = JsonConvert.DeserializeObject<dynamic>(token);

            long.TryParse(userToekn.sub, out long userId);
            return userId;
        }

        /// <summary>
        /// 删除Book信息的方法
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        //[AbpAuthorize(BookPermissions.Delete)]

        [HttpDelete]
        [UnitOfWork(IsDisabled = true)]
        public async Task Delete(EntityDto<uint> input)
        {
            //TODO:删除前的逻辑判断，是否允许删除
            await m_entityRepository.DeleteAsync(x => x.Id == input.Id);
        }

        /// <summary>
        /// 新增Book
        /// </summary>
        //[AbpAuthorize(BookPermissions.Create)]

        [HttpPost]
        [UnitOfWork]
        public virtual async Task<Book> Create(BookEditDto input)
        {
            //TODO:新增前的逻辑判断，是否允许新增

            var entity = Mapper.Map<Book>(input);
            entity.Id = null;
            if (entity != null)
            {
                var entityResult = await m_entityRepository.InsertAsync(entity);

                CurrentUnitOfWork.SaveChanges();
                return entityResult;
            }
            throw new UserFriendlyException("Sorry~ Create Failure");
        }

        [HttpPut]
        public virtual async Task<Book> Update(BookEditDto input)
        {
            //TODO:更新前的逻辑判断，是否允许更新
            //var entity = await m_entityRepository.GetAsync(input.Id.Value);

            var entity = await m_entityRepository
            .FirstOrDefaultAsync(x => x.Id == input.Id);
            Mapper.Map(input, entity);
            var entityResult = await m_entityRepository.UpdateAsync(entity);
            return entityResult;
        }

        /// <summary>
        /// 编辑Book
        /// </summary>
        //[AbpAuthorize(BookPermissions.Edit)]
        [UnitOfWork]
        [HttpPut]
        public virtual async Task BorrowBook(BookNameEditDto input)
        {
            //TODO:更新前的逻辑判断，是否允许更新
            var entity = await m_entityRepository
            .FirstOrDefaultAsync(x => x.Id == input.Id);
            if (CanBorrow(input))
            {
                entity.BorrowBooks();
                entity.MemberId = GetCurrentUserId();
                await m_entityRepository.UpdateAsync(entity);
            }
            else
            {
                throw new UserFriendlyException("当前图书不能被借阅");
            }
        }

        private bool CanBorrow(BookNameEditDto input)
        {
            return m_entityRepository.Get(input.Id.Value).State == BookServiceHostConsts.IsCanBorrowBook;
        }

        [HttpPut]
        public virtual async Task ReturnBook(uint bookId)
        {
            //TODO:更新前的逻辑判断，是否允许更新
            m_entityManager.ReturnBooks(bookId);
        }

        [HttpPut]
        public virtual async Task RemoveOfReportLoss(EntityDto<uint> input)
        {
            var entity = await m_entityRepository
            .FirstOrDefaultAsync(x => x.Id == input.Id);
            entity.RemoveOfReportLoss();
            await m_entityRepository.UpdateAsync(entity);
        }

        [HttpPut]
        public virtual async Task ReportLoss(EntityDto<uint> input)
        {
            var entity = await m_entityRepository
            .FirstOrDefaultAsync(x => x.Id == input.Id);
            entity.ReportLoss();
            await m_entityRepository.UpdateAsync(entity);
        }
    }
}