﻿namespace ResearchService.Host.Web
{
    public static class PermissionNames
    {
        public const string Pages = "Pages";

        public const string Pages_Tenants = "Pages.Tenants";

        public const string Pages_Users = "Pages.Users";
        //Green Channel

        public const string Green_Channel = "Green.Channel";

        #region Book

        public const string Pages_BookInfo = "Pages.BookInfo.Book.GetPages.Default";
        public const string Pages_BookInfo_Book_Create_Default = "Pages.BookInfo.Book.Create.Default";
        public const string Pages_BookInfo_Book_Update_Default = "Pages.BookInfo.Book.Update.Default";
        public const string Pages_BookInfo_Book_Borrow_Default = "Pages.BookInfo.Book.Borrow.Default";
        public const string Pages_BookInfo_Book_Return_Default = "Pages.BookInfo.Book.Return.Default";
        public const string Pages_BookInfo_Book_Delete_Default = "Pages.BookInfo.Book.Delete.Default";
        public const string Pages_BookInfo_Book_Get_Default = "Pages.BookInfo.Book.Get.Default";
        public const string Pages_BookInfo_Book_GetAll_Default = "Pages.BookInfo.Book.GetAll.Default";
        public const string Pages_BookInfo_Review_Create_Default = "Pages.BookInfo.Review.Create.Default";
        public const string Pages_BookInfo_Review_Create_Oneself = "Pages.BookInfo.Review.Create.Oneself";
        public const string Pages_BookInfo_Review_Create_Manager = "Pages.BookInfo.Review.Create.Manager";
        public const string Pages_BookInfo_Review_Update_Default = "Pages.BookInfo.Review.Update.Default";
        public const string Pages_BookInfo_Review_Update_Oneself = "Pages.BookInfo.Review.Update.Oneself";
        public const string Pages_BookInfo_Review_Update_Manager = "Pages.BookInfo.Review.Update.Manager";
        public const string Pages_BookInfo_Review_Delete_Default = "Pages.BookInfo.Review.Delete.Default";
        public const string Pages_BookInfo_Review_Get_Default = "Pages.BookInfo.Review.Get.Default";
        public const string Pages_BookInfo_Review_GetAll_Default = "Pages.BookInfo.Review.GetAll.Default";

        #endregion Book
    }
}