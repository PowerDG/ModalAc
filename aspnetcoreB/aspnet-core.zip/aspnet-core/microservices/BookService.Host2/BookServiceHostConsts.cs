﻿namespace BookService.Host
{
    public class BookServiceHostConsts
    {
        public const string LocalizationSourceName = "BookService";

        public const string ConnectionStringName = "Default";

        public const long DefaultBorrowBookMemberId = 0;
        public const int DefaultPageSize = 10;
        public const int MaxPageSize = 1000;

        public const byte IsCanBorrowBook = 0;
        public const byte IsBorrowedBook = 1;
        public const byte IsLostBook = 2;
    }
}