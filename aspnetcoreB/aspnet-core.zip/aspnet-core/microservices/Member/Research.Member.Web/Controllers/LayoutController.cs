namespace Research.Member.Web.Controllers
{
    public class LayoutController : MemberControllerBase
    {

    }
}