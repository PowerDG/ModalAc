namespace Research.Member.Dtos
{
    public class PagedSortedAndFilteredInputDto : PagedAndSortedInputDto
    {
        public string FilterText { get; set; }
    }
}