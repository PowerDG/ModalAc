

using System.Collections.Generic;
using Abp.Application.Services.Dto;
using Research.Member.Members;

namespace Research.Member.Members.Dtos
{
    public class GetMemberInfoForEditOutput
    {

        public MemberInfoEditDto MemberInfo { get; set; }

    }
}